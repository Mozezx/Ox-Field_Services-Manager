import React, { useState } from 'react';
import { AppView, Technician } from '../types';
import { ArrowLeft, Check, X, Eye, FileText, AlertTriangle, ChevronRight, ShieldCheck, Download } from 'lucide-react';
import { Button } from '../components/Button';

interface Props {
  setView: (view: AppView) => void;
}

// MOCK DATA
const mockTechs: Technician[] = [
  { id: '1', name: 'David Miller', role: 'Electrician', status: 'Pending', avatar: 'https://picsum.photos/seed/david/60/60', email: 'david@example.com', skills: ['HVAC', 'Wiring'] },
  { id: '2', name: 'Elena Rodriguez', role: 'Plumber', status: 'Pending', avatar: 'https://picsum.photos/seed/elena/60/60', email: 'elena@example.com', skills: ['Pipefitting'] },
  { id: '3', name: 'Sam Bridges', role: 'Courier', status: 'Rejected', avatar: 'https://picsum.photos/seed/sam/60/60', email: 'sam@bridges.com', skills: ['Driving'] },
];

// INBOX VIEW
export const ApprovalInbox: React.FC<Props> = ({ setView }) => {
  return (
    <div className="p-8 max-w-6xl mx-auto animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Technician Approvals</h1>
          <p className="text-secondary">Review pending applications and document verifications.</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-surface px-4 py-2 rounded-lg border border-white/10 flex flex-col items-center">
             <span className="text-2xl font-bold text-white">12</span>
             <span className="text-xs text-secondary uppercase">Pending</span>
          </div>
          <div className="bg-surface px-4 py-2 rounded-lg border border-white/10 flex flex-col items-center">
             <span className="text-2xl font-bold text-primary">4</span>
             <span className="text-xs text-secondary uppercase">Urgent</span>
          </div>
        </div>
      </div>

      <div className="bg-surface border border-white/10 rounded-xl overflow-hidden shadow-lg">
        <div className="grid grid-cols-12 gap-4 p-4 border-b border-white/10 bg-[#0f2a30] text-xs font-bold text-secondary uppercase tracking-wider">
          <div className="col-span-4">Technician</div>
          <div className="col-span-3">Role & Skills</div>
          <div className="col-span-3">Date Applied</div>
          <div className="col-span-2 text-right">Status</div>
        </div>

        {mockTechs.map((tech) => (
          <div 
            key={tech.id}
            onClick={() => tech.status === 'Pending' && setView(AppView.APPROVALS_VERIFICATION)}
            className={`
              grid grid-cols-12 gap-4 p-4 border-b border-white/5 items-center cursor-pointer transition-colors
              ${tech.status === 'Pending' ? 'hover:bg-white/5' : 'opacity-60'}
            `}
          >
            <div className="col-span-4 flex items-center gap-4">
              <img src={tech.avatar} className="w-10 h-10 rounded-full border border-white/10" />
              <div>
                <div className="font-bold text-white">{tech.name}</div>
                <div className="text-xs text-secondary">{tech.email}</div>
              </div>
            </div>
            <div className="col-span-3">
               <div className="text-white text-sm">{tech.role}</div>
               <div className="flex gap-1 mt-1">
                 {tech.skills.map(s => <span key={s} className="text-[10px] bg-white/10 px-1.5 rounded text-secondary">{s}</span>)}
               </div>
            </div>
            <div className="col-span-3 text-secondary text-sm">Oct 24, 2023</div>
            <div className="col-span-2 flex justify-end">
              <span className={`px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1
                ${tech.status === 'Pending' ? 'bg-amber-500/10 text-amber-500' : 'bg-red-500/10 text-red-500'}
              `}>
                {tech.status === 'Pending' ? 'Needs Review' : 'Rejected'}
                {tech.status === 'Pending' && <ChevronRight size={14} />}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// VERIFICATION & REJECTION FLOW
export const DocumentVerification: React.FC<Props> = ({ setView }) => {
  const [isRejectModalOpen, setRejectModalOpen] = useState(false);
  
  const tech = mockTechs[0]; // Simulate selected tech

  return (
    <div className="h-full flex flex-col animate-fade-in relative">
      {/* Header */}
      <div className="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-surface">
        <div className="flex items-center gap-4">
          <button onClick={() => setView(AppView.APPROVALS)} className="p-2 hover:bg-white/10 rounded-full text-secondary hover:text-white transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-lg font-bold text-white flex items-center gap-2">
              Verification: {tech.name}
              <span className="text-xs bg-amber-500/20 text-amber-500 px-2 py-0.5 rounded-full">Pending</span>
            </h1>
          </div>
        </div>
        <div className="flex gap-3">
           <Button variant="danger" onClick={() => setRejectModalOpen(true)}>Reject with Comment</Button>
           <Button variant="primary">Approve Application</Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Document Viewer (Left) */}
        <div className="flex-1 bg-[#081a1e] p-8 flex flex-col items-center justify-center relative">
          <div className="absolute top-4 right-4 flex gap-2">
            <button className="p-2 bg-black/40 text-white rounded hover:bg-black/60"><Download size={18} /></button>
            <button className="p-2 bg-black/40 text-white rounded hover:bg-black/60"><Eye size={18} /></button>
          </div>
          
          <div className="w-full max-w-2xl aspect-[3/4] bg-white shadow-2xl rounded-sm p-8 relative overflow-hidden group">
             {/* Mock Document */}
             <div className="border-4 border-double border-gray-200 h-full p-8 flex flex-col">
                <div className="flex justify-between items-center mb-8">
                   <div className="text-gray-900 font-serif text-2xl font-bold">CERTIFICATE</div>
                   <div className="w-16 h-16 rounded-full bg-yellow-400 opacity-20"></div>
                </div>
                <div className="space-y-4">
                  <div className="h-4 bg-gray-100 w-full rounded"></div>
                  <div className="h-4 bg-gray-100 w-3/4 rounded"></div>
                  <div className="h-4 bg-gray-100 w-5/6 rounded"></div>
                </div>
                <div className="mt-auto pt-8 border-t border-gray-300 flex justify-between">
                   <div className="text-gray-500 text-xs">Authorized Signature</div>
                   <div className="text-gray-500 text-xs">Date: 10/12/2022</div>
                </div>
             </div>
             
             {/* Mock Overlay for interaction */}
             <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex items-center justify-center">
                <span className="bg-black/70 text-white px-4 py-2 rounded-full text-sm">Click to Zoom</span>
             </div>
          </div>
        </div>

        {/* Checklist Sidebar (Right) */}
        <div className="w-96 bg-surface border-l border-white/10 flex flex-col">
           <div className="p-6 border-b border-white/10">
              <h3 className="font-bold text-white mb-1">Validation Checklist</h3>
              <p className="text-secondary text-sm">Verify all data points before approving.</p>
           </div>
           
           <div className="flex-1 overflow-y-auto p-6 space-y-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5"><ShieldCheck className="text-green-500" size={18} /></div>
                  <div>
                    <h4 className="text-white text-sm font-medium">Identity Match</h4>
                    <p className="text-secondary text-xs">Name matches application.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="mt-0.5"><AlertTriangle className="text-amber-500" size={18} /></div>
                  <div>
                    <h4 className="text-white text-sm font-medium">Expiration Check</h4>
                    <p className="text-secondary text-xs">Document expires in 30 days.</p>
                  </div>
                </div>
              </div>

              <hr className="border-white/10" />

              <div>
                <label className="block text-sm font-medium text-white mb-2">Internal Notes</label>
                <textarea 
                  className="w-full h-32 bg-[#0B242A] border border-white/10 rounded-lg p-3 text-white text-sm focus:ring-1 focus:ring-primary resize-none"
                  placeholder="Add notes about this verification..."
                />
              </div>
           </div>
        </div>
      </div>

      {/* REJECTION MODAL */}
      {isRejectModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-surface w-full max-w-lg rounded-xl border border-white/10 shadow-2xl p-6 animate-slide-up">
            <h2 className="text-xl font-bold text-white mb-4">Reject Document</h2>
            <p className="text-secondary text-sm mb-6">
              Please select a reason for rejection. This will be sent to the technician via email and push notification.
            </p>

            <div className="space-y-3 mb-6">
               {['Image is blurry or unreadable', 'Document has expired', 'Name does not match profile', 'Wrong document type'].map((reason, idx) => (
                 <label key={idx} className="flex items-center gap-3 p-3 rounded-lg border border-white/5 bg-[#0B242A] hover:border-primary/50 cursor-pointer transition-colors group">
                    <input type="radio" name="reason" className="text-primary focus:ring-primary bg-surface border-white/20" />
                    <span className="text-white text-sm group-hover:text-primary transition-colors">{reason}</span>
                 </label>
               ))}
            </div>

            <div>
              <label className="block text-xs font-medium text-secondary mb-2 uppercase tracking-wider">Additional Comments</label>
              <textarea 
                className="w-full h-24 bg-[#0B242A] border border-white/10 rounded-lg p-3 text-white text-sm focus:ring-1 focus:ring-primary resize-none"
                placeholder="Provide specific details..."
              />
            </div>

            <div className="flex justify-end gap-3 mt-8">
              <Button variant="ghost" onClick={() => setRejectModalOpen(false)}>Cancel</Button>
              <Button variant="danger" onClick={() => setRejectModalOpen(false)}>Confirm Rejection</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};