import React, { useState } from 'react';
import { AppView } from '../types';
import { Button } from '../components/Button';
import { ArrowRight, Check, Upload, UserPlus, Users } from 'lucide-react';

interface Props {
  setView: (view: AppView) => void;
}

// LOGIN SCREEN
export const LoginView: React.FC<Props> = ({ setView }) => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-20 pointer-events-none">
         <div className="absolute -top-[20%] -left-[10%] w-[600px] h-[600px] rounded-full bg-primary blur-[128px]" />
         <div className="absolute bottom-[0%] right-[0%] w-[500px] h-[500px] rounded-full bg-blue-600 blur-[128px]" />
      </div>

      <div className="w-full max-w-md bg-surface p-8 rounded-2xl border border-white/10 shadow-2xl z-10 mx-4">
        <div className="mb-8 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-blue-600 rounded-2xl mx-auto flex items-center justify-center text-[#0B242A] font-bold text-3xl mb-4">Ox</div>
          <h1 className="text-3xl font-bold text-white mb-2">Welcome Back</h1>
          <p className="text-secondary">Enter your credentials to access your workspace.</p>
        </div>

        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setView(AppView.ONBOARDING_1); }}>
          <div>
            <label className="block text-sm font-medium text-secondary mb-1">Email</label>
            <input 
              type="email" 
              className="w-full bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
              placeholder="name@company.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary mb-1">Password</label>
            <input 
              type="password" 
              className="w-full bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
              placeholder="••••••••"
            />
          </div>
          <Button fullWidth className="mt-6 py-3">Sign Up & Start Setup</Button>
        </form>
        
        <div className="mt-6 text-center text-sm text-secondary">
          Already have an account? <span className="text-primary cursor-pointer hover:underline">Log in</span>
        </div>
      </div>
    </div>
  );
};

// ONBOARDING LAYOUT WRAPPER
const OnboardingLayout: React.FC<{
  step: number;
  title: string;
  subtitle: string;
  children: React.ReactNode;
  onNext: () => void;
  btnText?: string;
}> = ({ step, title, subtitle, children, onNext, btnText = 'Next' }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background relative px-4">
       {/* Background Decor */}
       <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-10 pointer-events-none">
         <div className="absolute top-[20%] right-[30%] w-[400px] h-[400px] rounded-full bg-primary blur-[100px]" />
      </div>

      <div className="w-full max-w-2xl">
        {/* Progress */}
        <div className="mb-8 flex items-center justify-between text-sm font-medium text-secondary">
          <span>Step {step} of 3</span>
          <div className="flex gap-2">
            {[1, 2, 3].map(i => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-500 ${i <= step ? 'w-8 bg-primary' : 'w-2 bg-white/10'}`}
              />
            ))}
          </div>
        </div>

        <div className="bg-surface border border-white/5 p-8 md:p-12 rounded-2xl shadow-2xl backdrop-blur-sm relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl font-bold text-white mb-2">{title}</h2>
            <p className="text-secondary mb-8">{subtitle}</p>
            
            <div className="min-h-[200px] mb-8">
              {children}
            </div>

            <div className="flex justify-end pt-6 border-t border-white/5">
              <Button onClick={onNext} className="px-8 py-3 text-lg">
                {btnText} <ArrowRight size={20} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// STEP 1: SETUP
export const SetupView: React.FC<Props> = ({ setView }) => {
  return (
    <OnboardingLayout 
      step={1}
      title="Setup your Organization"
      subtitle="Tell us a bit about your company to customize your workspace."
      onNext={() => setView(AppView.ONBOARDING_2)}
    >
      <div className="space-y-6">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-full border-2 border-dashed border-white/20 flex flex-col items-center justify-center text-secondary hover:text-primary hover:border-primary cursor-pointer transition-colors bg-[#0B242A]">
            <Upload size={24} />
            <span className="text-xs mt-2">Logo</span>
          </div>
          <div className="flex-1">
             <label className="block text-sm font-medium text-secondary mb-1">Company Name</label>
            <input 
              type="text" 
              defaultValue="Ox Field Services"
              className="w-full bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-secondary mb-1">Industry</label>
            <select className="w-full bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary outline-none">
              <option>HVAC</option>
              <option>Plumbing</option>
              <option>Electrical</option>
              <option>General Maintenance</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-secondary mb-1">Team Size</label>
             <select className="w-full bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary outline-none">
              <option>1-10</option>
              <option>11-50</option>
              <option>50+</option>
            </select>
          </div>
        </div>
      </div>
    </OnboardingLayout>
  );
};

// STEP 2: TEAM INVITATION
export const TeamInvitationView: React.FC<Props> = ({ setView }) => {
  const [emails, setEmails] = useState(['']);

  return (
    <OnboardingLayout 
      step={2}
      title="Invite your Team"
      subtitle="Add your technicians and dispatchers. You can add more later."
      onNext={() => setView(AppView.ONBOARDING_3)}
    >
      <div className="space-y-4">
        {emails.map((_, idx) => (
          <div key={idx} className="flex gap-3">
            <input 
              type="email" 
              placeholder="colleague@company.com"
              className="flex-1 bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary outline-none"
            />
             <select className="w-32 bg-[#0B242A] border border-white/10 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-primary outline-none">
              <option>Admin</option>
              <option>Tech</option>
              <option>Viewer</option>
            </select>
          </div>
        ))}
        
        <button 
          onClick={() => setEmails([...emails, ''])}
          className="flex items-center gap-2 text-primary hover:text-white font-medium transition-colors text-sm mt-2"
        >
          <UserPlus size={16} /> Add another member
        </button>

        <div className="mt-8 p-4 bg-primary/10 rounded-lg border border-primary/20 flex items-start gap-3">
          <Users className="text-primary shrink-0 mt-0.5" size={20} />
          <div>
            <h4 className="text-white font-medium text-sm">Bulk Import?</h4>
            <p className="text-secondary text-xs mt-1">You can upload a CSV file with your team details in the settings later.</p>
          </div>
        </div>
      </div>
    </OnboardingLayout>
  );
};

// STEP 3: COMPLETION
export const CompletionView: React.FC<Props> = ({ setView }) => {
  return (
    <OnboardingLayout 
      step={3}
      title="You're All Set!"
      subtitle="Your workspace is ready. Let's start managing your operations."
      onNext={() => setView(AppView.DASHBOARD)}
      btnText="Start Managing"
    >
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mb-6 animate-bounce">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center text-[#0B242A]">
            <Check size={32} strokeWidth={4} />
          </div>
        </div>
        
        <h3 className="text-xl font-semibold text-white mb-2">Workspace Created Successfully</h3>
        <p className="text-secondary max-w-md">
          We've set up your dashboard with some sample data so you can explore the features right away.
        </p>

        <div className="grid grid-cols-3 gap-4 mt-8 w-full">
           <div className="p-4 bg-[#0B242A] rounded-xl border border-white/5 text-center">
              <div className="text-2xl font-bold text-white mb-1">Dispatch</div>
              <div className="text-xs text-secondary">Assign Jobs</div>
           </div>
           <div className="p-4 bg-[#0B242A] rounded-xl border border-white/5 text-center">
              <div className="text-2xl font-bold text-white mb-1">Map</div>
              <div className="text-xs text-secondary">Track Fleet</div>
           </div>
           <div className="p-4 bg-[#0B242A] rounded-xl border border-white/5 text-center">
              <div className="text-2xl font-bold text-white mb-1">Approve</div>
              <div className="text-xs text-secondary">Verify Docs</div>
           </div>
        </div>
      </div>
    </OnboardingLayout>
  );
};