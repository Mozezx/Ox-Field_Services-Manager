import React from 'react';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Activity, Users, DollarSign, Clock } from 'lucide-react';

const data = [
  { name: 'Mon', jobs: 12 },
  { name: 'Tue', jobs: 19 },
  { name: 'Wed', jobs: 15 },
  { name: 'Thu', jobs: 22 },
  { name: 'Fri', jobs: 30 },
  { name: 'Sat', jobs: 25 },
  { name: 'Sun', jobs: 18 },
];

export const OperationsDashboard: React.FC = () => {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-white">Operations & KPI Dashboard</h1>
        <p className="text-secondary">Real-time overview of fleet performance.</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-surface p-6 rounded-xl border border-white/10 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
          <div className="flex items-center gap-4 mb-4">
             <div className="p-3 bg-blue-500/20 rounded-lg text-blue-400"><Activity size={24} /></div>
             <div className="text-secondary font-medium">Total Jobs</div>
          </div>
          <div className="text-3xl font-bold text-white">1,284</div>
          <div className="text-green-400 text-sm mt-1 flex items-center gap-1">↑ 12% <span className="text-secondary">vs last week</span></div>
        </div>

        <div className="bg-surface p-6 rounded-xl border border-white/10 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
          <div className="flex items-center gap-4 mb-4">
             <div className="p-3 bg-green-500/20 rounded-lg text-green-400"><DollarSign size={24} /></div>
             <div className="text-secondary font-medium">Revenue</div>
          </div>
          <div className="text-3xl font-bold text-white">$48.2k</div>
          <div className="text-green-400 text-sm mt-1 flex items-center gap-1">↑ 8% <span className="text-secondary">vs last week</span></div>
        </div>

        <div className="bg-surface p-6 rounded-xl border border-white/10 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
          <div className="flex items-center gap-4 mb-4">
             <div className="p-3 bg-amber-500/20 rounded-lg text-amber-400"><Clock size={24} /></div>
             <div className="text-secondary font-medium">Avg Response</div>
          </div>
          <div className="text-3xl font-bold text-white">42m</div>
          <div className="text-red-400 text-sm mt-1 flex items-center gap-1">↓ 2m <span className="text-secondary">slower</span></div>
        </div>

         <div className="bg-surface p-6 rounded-xl border border-white/10 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/10 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
          <div className="flex items-center gap-4 mb-4">
             <div className="p-3 bg-purple-500/20 rounded-lg text-purple-400"><Users size={24} /></div>
             <div className="text-secondary font-medium">Active Techs</div>
          </div>
          <div className="text-3xl font-bold text-white">24/30</div>
          <div className="text-secondary text-sm mt-1">80% Utilization</div>
        </div>
      </div>

      {/* Chart Section */}
      <div className="bg-surface p-6 rounded-xl border border-white/10 shadow-lg">
        <h3 className="text-xl font-bold text-white mb-6">Weekly Job Completion</h3>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorJobs" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22D3EE" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#22D3EE" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="name" stroke="#94A3B8" />
              <YAxis stroke="#94A3B8" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#132F35', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Area type="monotone" dataKey="jobs" stroke="#22D3EE" strokeWidth={3} fillOpacity={1} fill="url(#colorJobs)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export const PlaceholderView: React.FC<{title: string}> = ({ title }) => (
  <div className="h-full flex flex-col items-center justify-center text-center p-8 animate-fade-in">
    <div className="w-32 h-32 bg-surface rounded-full flex items-center justify-center mb-6 animate-pulse">
       <span className="text-4xl">🚧</span>
    </div>
    <h1 className="text-3xl font-bold text-white mb-2">{title}</h1>
    <p className="text-secondary max-w-md">This view is currently under construction in this prototype.</p>
  </div>
);