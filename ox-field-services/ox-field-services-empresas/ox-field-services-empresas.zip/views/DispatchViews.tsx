import React, { useState } from 'react';
import { ServiceOrder } from '../types';
import { User, Clock, MapPin, Calendar, MessageSquare, Image as ImageIcon, X, MoreVertical } from 'lucide-react';
import { Button } from '../components/Button';

// MOCK DATA
const technicians = [
  { id: 't1', name: 'Mike Ross', avatar: 'https://picsum.photos/seed/mike/40/40' },
  { id: 't2', name: 'Sarah Connor', avatar: 'https://picsum.photos/seed/sarah/40/40' },
  { id: 't3', name: 'John Wick', avatar: 'https://picsum.photos/seed/john/40/40' },
];

const orders: ServiceOrder[] = [
  { id: 'OS-8842', title: 'HVAC Repair', customer: 'Acme Corp', status: 'In Progress', start: 9, duration: 3, techId: 't1' },
  { id: 'OS-8843', title: 'Maintenance', customer: 'Wayne Ent', status: 'Completed', start: 8, duration: 2, techId: 't2' },
  { id: 'OS-8845', title: 'Install', customer: 'Stark Ind', status: 'Scheduled', start: 13, duration: 4, techId: 't1' },
];

export const DispatchConsole: React.FC = () => {
  const [selectedOrder, setSelectedOrder] = useState<ServiceOrder | null>(null);

  const hours = Array.from({ length: 12 }, (_, i) => i + 7); // 7am to 6pm

  return (
    <div className="h-full flex flex-col bg-background overflow-hidden animate-fade-in">
      {/* Header */}
      <div className="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-surface">
        <h1 className="text-xl font-bold text-white">Dispatch Scheduling Console</h1>
        <div className="flex gap-3">
          <Button variant="secondary">Day</Button>
          <Button variant="secondary">Week</Button>
          <Button>+ New Order</Button>
        </div>
      </div>

      {/* Gantt Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Tech List Sidebar */}
        <div className="w-64 border-r border-white/10 bg-surface flex flex-col">
          <div className="h-12 border-b border-white/5 flex items-center px-4 text-xs font-medium text-secondary uppercase tracking-wider">
            Technicians
          </div>
          {technicians.map(tech => (
            <div key={tech.id} className="h-20 flex items-center px-4 gap-3 border-b border-white/5 hover:bg-white/5 transition-colors">
              <img src={tech.avatar} alt={tech.name} className="w-10 h-10 rounded-full border border-white/10" />
              <div>
                <div className="text-white font-medium">{tech.name}</div>
                <div className="text-xs text-secondary">Active • 3 Jobs</div>
              </div>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div className="flex-1 overflow-x-auto relative bg-[#0B242A]">
          {/* Time Header */}
          <div className="h-12 flex border-b border-white/10 sticky top-0 bg-[#0B242A] z-10 min-w-max">
            {hours.map(h => (
              <div key={h} className="w-32 border-r border-white/5 flex items-center justify-center text-xs text-secondary">
                {h}:00
              </div>
            ))}
          </div>

          {/* Grid */}
          <div className="min-w-max">
            {technicians.map(tech => (
              <div key={tech.id} className="h-20 flex border-b border-white/5 relative">
                {hours.map(h => (
                  <div key={h} className="w-32 border-r border-white/5 h-full" />
                ))}
                
                {/* Render Orders for this Tech */}
                {orders.filter(o => o.techId === tech.id).map(order => {
                  const offset = (order.start - 7) * 128; // 128px per hour (w-32)
                  const width = order.duration * 128;
                  
                  let statusColor = 'bg-blue-600';
                  if (order.status === 'In Progress') statusColor = 'bg-amber-600';
                  if (order.status === 'Completed') statusColor = 'bg-green-600';

                  return (
                    <button
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className={`absolute top-2 bottom-2 rounded-lg ${statusColor} border border-white/20 p-2 text-left hover:brightness-110 transition-all shadow-lg group`}
                      style={{ left: `${offset}px`, width: `${width - 8}px` }}
                    >
                      <div className="flex justify-between items-start">
                        <span className="text-xs font-bold text-white shadow-black drop-shadow-md">{order.id}</span>
                        <MoreVertical size={14} className="text-white opacity-0 group-hover:opacity-100" />
                      </div>
                      <div className="text-xs text-white/90 truncate font-medium">{order.title}</div>
                      <div className="text-[10px] text-white/70 truncate">{order.customer}</div>
                    </button>
                  );
                })}
              </div>
            ))}
            
            {/* Current Time Indicator Line */}
            <div className="absolute top-0 bottom-0 left-[340px] w-0.5 bg-primary z-20 pointer-events-none">
              <div className="absolute -top-1 -left-1.5 w-3 h-3 bg-primary rounded-full shadow-lg shadow-primary/50" />
            </div>
          </div>
        </div>
      </div>

      {/* EDIT MODAL OVERLAY */}
      {selectedOrder && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
           {/* Slide In Animation Wrapper */}
          <div className="bg-surface w-full max-w-4xl h-[85vh] rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col animate-slide-up">
            
            {/* Modal Header */}
            <div className="h-16 border-b border-white/10 flex items-center justify-between px-6 bg-surface">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-3">
                  {selectedOrder.title} <span className="text-secondary font-normal text-base">#{selectedOrder.id}</span>
                </h2>
                <div className="flex items-center gap-2 text-xs mt-1">
                   <span className={`w-2 h-2 rounded-full ${selectedOrder.status === 'In Progress' ? 'bg-amber-500 animate-pulse' : 'bg-green-500'}`} />
                   <span className="text-secondary">{selectedOrder.status}</span>
                </div>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="text-secondary hover:text-white bg-white/5 p-2 rounded-full transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="flex-1 flex overflow-hidden">
               {/* Details Column */}
               <div className="w-1/3 border-r border-white/10 p-6 overflow-y-auto bg-[#0f2a30]">
                  <h3 className="text-sm font-bold text-secondary uppercase tracking-wider mb-4">Job Details</h3>
                  
                  <div className="space-y-6">
                    <div className="flex gap-3">
                       <User className="text-primary mt-0.5" size={18} />
                       <div>
                         <label className="block text-xs text-secondary">Customer</label>
                         <div className="text-white font-medium">{selectedOrder.customer}</div>
                         <div className="text-xs text-secondary">123 Industrial Park, Sector 7</div>
                       </div>
                    </div>

                    <div className="flex gap-3">
                       <Calendar className="text-primary mt-0.5" size={18} />
                       <div>
                         <label className="block text-xs text-secondary">Schedule</label>
                         <div className="text-white font-medium">Oct 24, 2023</div>
                         <div className="text-xs text-secondary">{selectedOrder.start}:00 - {selectedOrder.start + selectedOrder.duration}:00</div>
                       </div>
                    </div>

                    <div className="p-4 bg-black/20 rounded-lg border border-white/5">
                      <h4 className="text-xs font-bold text-white mb-2">Required Parts</h4>
                      <ul className="text-sm text-secondary space-y-1 list-disc list-inside">
                        <li>Filter Unit X-99</li>
                        <li>Compressor Oil (5L)</li>
                        <li>Safety Valve</li>
                      </ul>
                    </div>
                  </div>
               </div>

               {/* Chat & Photos Column */}
               <div className="flex-1 flex flex-col bg-surface">
                  {/* Chat Area */}
                  <div className="flex-1 p-6 overflow-y-auto space-y-4">
                     <div className="flex justify-center"><span className="text-xs text-secondary bg-white/5 px-3 py-1 rounded-full">Today</span></div>
                     
                     <div className="flex gap-3">
                       <img src={technicians[0].avatar} className="w-8 h-8 rounded-full" />
                       <div className="bg-white/10 p-3 rounded-2xl rounded-tl-none text-sm text-white max-w-[80%]">
                         Arrived on site. The unit is larger than expected. Might need extra coolant.
                       </div>
                     </div>

                     <div className="flex gap-3 flex-row-reverse">
                       <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-[#0B242A] font-bold">D</div>
                       <div className="bg-primary/20 border border-primary/20 p-3 rounded-2xl rounded-tr-none text-sm text-white max-w-[80%]">
                         Copy that. Check the warehouse inventory, I think we have spares in truck 4.
                       </div>
                     </div>
                  </div>

                  {/* Actions Area */}
                  <div className="p-4 border-t border-white/10 bg-[#0f2a30]">
                     {/* Photos Preview */}
                     <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
                        <div className="w-16 h-16 bg-black/40 rounded-lg border border-white/10 flex items-center justify-center text-secondary hover:text-white hover:border-primary cursor-pointer transition-colors">
                          <ImageIcon size={20} />
                        </div>
                        <img src="https://picsum.photos/seed/hvac1/100/100" className="w-16 h-16 rounded-lg object-cover border border-white/10" />
                        <img src="https://picsum.photos/seed/hvac2/100/100" className="w-16 h-16 rounded-lg object-cover border border-white/10" />
                     </div>
                     
                     {/* Input */}
                     <div className="flex gap-2">
                       <input 
                         type="text" 
                         placeholder="Type a message to technician..." 
                         className="flex-1 bg-black/20 border border-white/10 rounded-lg px-4 text-white focus:ring-1 focus:ring-primary outline-none"
                       />
                       <Button><MessageSquare size={18} /> Send</Button>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};