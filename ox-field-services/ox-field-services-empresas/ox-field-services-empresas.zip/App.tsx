import React, { useState } from 'react';
import { AppView } from './types';
import { Sidebar } from './components/Sidebar';
import { LoginView, SetupView, TeamInvitationView, CompletionView } from './views/OnboardingViews';
import { OperationsDashboard, PlaceholderView } from './views/DashboardViews';
import { DispatchConsole } from './views/DispatchViews';
import { ApprovalInbox, DocumentVerification } from './views/ApprovalViews';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LOGIN);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Render Logic
  const renderView = () => {
    switch (currentView) {
      case AppView.LOGIN:
        return <LoginView setView={setCurrentView} />;
      case AppView.ONBOARDING_1:
        return <SetupView setView={setCurrentView} />;
      case AppView.ONBOARDING_2:
        return <TeamInvitationView setView={setCurrentView} />;
      case AppView.ONBOARDING_3:
        return <CompletionView setView={setCurrentView} />;
      case AppView.DASHBOARD:
        return <OperationsDashboard />;
      case AppView.DISPATCH:
        return <DispatchConsole />;
      case AppView.MAP:
        return <PlaceholderView title="Live Fleet Monitoring Map" />;
      case AppView.INVENTORY:
        return <PlaceholderView title="Inventory Management" />;
      case AppView.APPROVALS:
        return <ApprovalInbox setView={setCurrentView} />;
      case AppView.APPROVALS_VERIFICATION:
        return <DocumentVerification setView={setCurrentView} />;
      case AppView.BILLING:
         return <PlaceholderView title="Account & Billing" />;
      default:
        return <OperationsDashboard />;
    }
  };

  // Check if current view should show sidebar
  const showSidebar = ![
    AppView.LOGIN, 
    AppView.ONBOARDING_1, 
    AppView.ONBOARDING_2, 
    AppView.ONBOARDING_3
  ].includes(currentView);

  return (
    <div className="min-h-screen bg-background text-white font-sans selection:bg-primary selection:text-[#0B242A]">
      {showSidebar && (
        <Sidebar 
          currentView={currentView} 
          setView={setCurrentView} 
          isCollapsed={isSidebarCollapsed}
          toggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />
      )}
      
      <main 
        className={`
          min-h-screen transition-all duration-300
          ${showSidebar ? (isSidebarCollapsed ? 'ml-20' : 'ml-64') : ''}
        `}
      >
        {renderView()}
      </main>
    </div>
  );
}