import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LoginScreen } from './screens/auth/LoginScreen';
import { RegisterStep1, RegisterStep2, RegisterStep3, ApprovalScreen } from './screens/auth/RegisterScreens';
import { AgendaScreen } from './screens/main/AgendaScreen';
import { TaskExecutionScreen } from './screens/task/TaskExecutionScreen';
import { MaterialsLogScreen } from './screens/task/MaterialsLogScreen';
import { ServiceCompletionScreen } from './screens/task/ServiceCompletionScreen';
import { SyncManagerScreen } from './screens/support/SyncManagerScreen';
import { NotificationsScreen } from './screens/support/NotificationsScreen';
import { HistoryScreen } from './screens/support/HistoryScreen';
import { DashboardScreen } from './screens/support/ProductivityDashboardScreen';
import { ProfileScreen } from './screens/support/ProfileScreen';
import { SupportChatScreen } from './screens/support/SupportChatScreen';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginScreen />} />
        
        {/* Registration Flow */}
        <Route path="/register/1" element={<RegisterStep1 />} />
        <Route path="/register/2" element={<RegisterStep2 />} />
        <Route path="/register/3" element={<RegisterStep3 />} />
        <Route path="/approval" element={<ApprovalScreen />} />

        {/* Main App */}
        <Route path="/agenda" element={<AgendaScreen />} />
        
        {/* Task Execution Flow */}
        <Route path="/task/:taskId" element={<TaskExecutionScreen />} />
        <Route path="/task/:taskId/materials" element={<MaterialsLogScreen />} />
        <Route path="/task/:taskId/complete" element={<ServiceCompletionScreen />} />

        {/* Support Screens */}
        <Route path="/sync" element={<SyncManagerScreen />} />
        <Route path="/notifications" element={<NotificationsScreen />} />
        <Route path="/history" element={<HistoryScreen />} />
        <Route path="/dashboard" element={<DashboardScreen />} />
        <Route path="/profile" element={<ProfileScreen />} />
        <Route path="/chat" element={<SupportChatScreen />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
