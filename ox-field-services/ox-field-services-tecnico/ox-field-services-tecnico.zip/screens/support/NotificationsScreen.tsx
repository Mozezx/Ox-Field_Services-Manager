import React from 'react';
import { useNavigate } from 'react-router-dom';

export const NotificationsScreen: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-bg-dark text-white pb-6">
       <div className="sticky top-0 z-20 bg-bg-dark/95 backdrop-blur-md border-b border-white/5 px-4 py-3 flex justify-between items-center">
          <button onClick={() => navigate(-1)} className="size-10 flex items-center justify-center rounded-full hover:bg-white/10">
             <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <h2 className="text-lg font-bold">Notifications</h2>
          <button className="size-10 flex items-center justify-center rounded-full hover:bg-white/10 text-secondary">
             <span className="material-symbols-outlined">done_all</span>
          </button>
       </div>

       <div className="px-4 py-3 flex gap-2 overflow-x-auto no-scrollbar sticky top-[60px] z-10 bg-bg-dark pb-4">
          <button className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-secondary text-primary text-sm font-semibold">
             All <span className="bg-black/10 text-[10px] px-1.5 py-0.5 rounded-full ml-1">5</span>
          </button>
          <button className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-surface-dark border border-slate-700 text-slate-400 text-sm font-medium">Assignments</button>
          <button className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-surface-dark border border-slate-700 text-slate-400 text-sm font-medium">Alerts</button>
       </div>

       <div className="px-4 flex flex-col gap-4">
          <div className="bg-surface-dark border border-slate-700 rounded-2xl p-4 relative overflow-hidden group hover:border-secondary/50 transition-colors">
             <div className="absolute top-4 right-4 h-2.5 w-2.5 rounded-full bg-secondary shadow-[0_0_8px_#13ec5b]"></div>
             <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                   <div className="size-8 rounded-full bg-white/5 flex items-center justify-center text-secondary">
                      <span className="material-symbols-outlined text-lg">assignment_add</span>
                   </div>
                   <div>
                      <p className="text-xs font-medium text-slate-400 uppercase">New Assignment</p>
                      <p className="text-xs text-slate-500">2 min ago</p>
                   </div>
                </div>
                <span className="px-2.5 py-1 rounded-md bg-red-900/20 border border-red-900/50 text-red-300 text-[10px] font-bold uppercase mr-4">High Priority</span>
             </div>
             <h3 className="text-lg font-bold mb-2">OS #4821 - Industrial HVAC Repair</h3>
             <div className="space-y-2 mb-4">
                <div className="flex items-start gap-2 text-sm text-slate-300">
                   <span className="material-symbols-outlined text-lg text-slate-500">location_on</span>
                   Sector 4, 123 Industrial Park Way
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-300">
                   <span className="material-symbols-outlined text-lg text-slate-500">schedule</span>
                   Today, 2:00 PM - 4:00 PM
                </div>
             </div>
             <button onClick={() => navigate('/task/4821')} className="w-full bg-primary hover:bg-primary/90 text-white py-2.5 rounded-xl font-semibold text-sm transition-colors flex items-center justify-center gap-2">
                Quick View <span className="material-symbols-outlined text-lg">arrow_forward</span>
             </button>
          </div>

          <div className="flex items-start gap-3 bg-surface-dark/40 border border-slate-800 p-4 rounded-2xl">
             <div className="shrink-0 size-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300">
                <span className="material-symbols-outlined text-[20px]">cloud_sync</span>
             </div>
             <div className="flex-1">
                <div className="flex justify-between mb-0.5">
                   <p className="text-sm font-bold">Sync Completed</p>
                   <span className="text-[10px] text-slate-500">10:42 AM</span>
                </div>
                <p className="text-xs text-slate-400">All photos for <span className="text-white font-medium">OS #4819</span> have been uploaded.</p>
             </div>
          </div>
       </div>
    </div>
  );
};
