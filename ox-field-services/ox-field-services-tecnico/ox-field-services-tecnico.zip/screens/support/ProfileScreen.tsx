import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BottomNav } from '../../components/BottomNav';

export const ProfileScreen: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark text-white pb-24">
       <header className="flex items-center gap-4 p-4 sticky top-0 bg-bg-dark/95 backdrop-blur z-20">
          <button onClick={() => navigate(-1)} className="size-10 flex items-center justify-center rounded-full hover:bg-white/10"><span className="material-symbols-outlined">arrow_back</span></button>
          <h1 className="text-lg font-bold">Profile & Settings</h1>
       </header>

       <div className="flex flex-col items-center mt-6 mb-8">
          <div className="relative">
             <div className="size-28 rounded-full border-4 border-primary overflow-hidden">
                <img src="https://picsum.photos/id/64/400/400" className="w-full h-full object-cover" />
             </div>
             <div className="absolute bottom-1 right-1 size-6 bg-secondary border-4 border-bg-dark rounded-full"></div>
          </div>
          <h2 className="text-xl font-bold mt-4">Alex Miller</h2>
          <div className="flex items-center gap-2 mt-1">
             <span className="px-2 py-0.5 rounded bg-white/10 text-xs text-slate-300">Senior Technician</span>
             <span className="text-xs text-slate-500">ID: OX-8821</span>
          </div>
       </div>

       <div className="px-4 space-y-6">
          <div>
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 pl-2">General</h3>
             <div className="bg-surface-dark rounded-2xl overflow-hidden">
                {[
                   { icon: 'edit', label: 'Edit Profile' },
                   { icon: 'notifications', label: 'Notification Preferences' },
                   { icon: 'language', label: 'Language', sub: 'English' }
                ].map((item, idx) => (
                   <div key={idx} className="flex items-center justify-between p-4 hover:bg-white/5 cursor-pointer border-b border-white/5 last:border-0">
                      <div className="flex items-center gap-4">
                         <div className="size-10 rounded-xl bg-white/5 flex items-center justify-center text-accent">
                            <span className="material-symbols-outlined">{item.icon}</span>
                         </div>
                         <span className="font-medium">{item.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                         {item.sub && <span className="text-sm text-slate-500">{item.sub}</span>}
                         <span className="material-symbols-outlined text-slate-500 text-sm">chevron_right</span>
                      </div>
                   </div>
                ))}
             </div>
          </div>

          <div>
             <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 pl-2">Preferences</h3>
             <div className="bg-surface-dark rounded-2xl overflow-hidden">
                <div className="flex items-center justify-between p-4 hover:bg-white/5 border-b border-white/5">
                   <div className="flex items-center gap-4">
                      <div className="size-10 rounded-xl bg-white/5 flex items-center justify-center text-accent">
                         <span className="material-symbols-outlined">dark_mode</span>
                      </div>
                      <span className="font-medium">App Theme</span>
                   </div>
                   <div className="bg-black/20 rounded-lg p-0.5 flex">
                      <button className="px-3 py-1 rounded-md text-xs text-slate-400">Light</button>
                      <button className="px-3 py-1 rounded-md bg-white/10 text-xs font-bold">Dark</button>
                   </div>
                </div>
                <div className="flex items-center justify-between p-4 hover:bg-white/5 cursor-pointer">
                   <div className="flex items-center gap-4">
                      <div className="size-10 rounded-xl bg-white/5 flex items-center justify-center text-accent">
                         <span className="material-symbols-outlined">help</span>
                      </div>
                      <span className="font-medium">Help & Support</span>
                   </div>
                   <span className="material-symbols-outlined text-slate-500 text-sm">chevron_right</span>
                </div>
             </div>
          </div>
          
          <button onClick={() => navigate('/')} className="w-full py-4 rounded-2xl border border-red-500/20 text-red-400 font-bold hover:bg-red-500/10 transition-colors flex items-center justify-center gap-2">
             <span className="material-symbols-outlined">logout</span> Log Out
          </button>
       </div>
       <BottomNav />
    </div>
  );
};
