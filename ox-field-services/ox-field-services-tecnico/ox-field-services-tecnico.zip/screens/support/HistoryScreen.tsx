import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BottomNav } from '../../components/BottomNav';

export const HistoryScreen: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark text-white pb-24">
       <header className="flex items-center justify-between px-4 py-3 bg-primary">
          <button onClick={() => navigate('/agenda')} className="size-10 flex items-center justify-center rounded-full hover:bg-white/10">
             <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <h1 className="text-lg font-bold">Service History</h1>
          <button className="size-10 flex items-center justify-center rounded-full hover:bg-white/10">
             <span className="material-symbols-outlined">calendar_month</span>
          </button>
       </header>

       <div className="sticky top-0 z-10 bg-bg-dark/95 backdrop-blur-md pt-4 pb-2 border-b border-white/5">
          <div className="px-4 mb-3">
             <div className="flex w-full items-center rounded-xl bg-primary/40 border border-white/10 h-12 overflow-hidden px-4">
                <span className="material-symbols-outlined text-slate-400">search</span>
                <input className="w-full bg-transparent border-none text-white pl-3 focus:ring-0 placeholder-slate-400" placeholder="Search OS # or Client..." />
             </div>
          </div>
          <div className="flex gap-2 px-4 overflow-x-auto no-scrollbar pb-2">
             <button className="h-8 px-4 rounded-full bg-primary text-white text-sm font-medium border border-transparent">All</button>
             {['Last 7 Days', 'This Month', 'Last Month'].map(t => (
                <button key={t} className="h-8 px-4 rounded-full bg-primary/30 text-slate-300 text-sm font-medium border border-white/10 whitespace-nowrap">{t}</button>
             ))}
          </div>
       </div>

       <div className="p-4 flex flex-col gap-4">
          {[
            { id: 'OS-8821', client: 'Acme Industrial Corp.', date: 'Oct 24, 2023', type: 'HVAC Maintenance' },
            { id: 'OS-8820', client: 'Stark Industries', date: 'Oct 23, 2023', type: 'System Diagnostics' },
            { id: 'OS-8819', client: 'Wayne Enterprises', date: 'Oct 21, 2023', type: 'Safety Inspection' },
            { id: 'OS-8815', client: 'Cyberdyne Systems', date: 'Oct 18, 2023', type: 'Unit Replacement' }
          ].map(job => (
             <div key={job.id} className="group flex flex-col gap-3 rounded-xl bg-primary p-4 shadow-sm border border-white/5 active:scale-[0.99] transition-transform">
                <div className="flex justify-between items-start">
                   <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-xs font-medium text-slate-400 uppercase tracking-wide">
                         <span>{job.id}</span>
                         <span className="size-1 rounded-full bg-slate-400"></span>
                         <span>{job.date}</span>
                      </div>
                      <h3 className="text-lg font-bold leading-tight">{job.client}</h3>
                   </div>
                   <span className="material-symbols-outlined text-slate-500">chevron_right</span>
                </div>
                <div className="flex items-center justify-between mt-1">
                   <div className="flex items-center gap-2">
                      <span className="inline-flex items-center gap-1.5 rounded-md bg-green-500/20 px-2.5 py-1 text-xs font-semibold text-green-400 border border-green-500/20">
                         <span className="material-symbols-outlined text-[16px] filled">check_circle</span>
                         Completed
                      </span>
                   </div>
                   <div className="text-xs text-slate-400 font-medium">{job.type}</div>
                </div>
             </div>
          ))}
          <div className="py-4 flex justify-center text-xs text-slate-500">End of list</div>
       </div>
       <BottomNav />
    </div>
  );
};
