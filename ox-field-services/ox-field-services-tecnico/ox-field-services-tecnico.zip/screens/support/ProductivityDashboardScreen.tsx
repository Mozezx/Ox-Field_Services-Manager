import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BottomNav } from '../../components/BottomNav';
import { BarChart, Bar, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'M', val: 40 },
  { name: 'T', val: 65 },
  { name: 'W', val: 85 }, // Peak
  { name: 'T', val: 55 },
  { name: 'F', val: 75 },
  { name: 'S', val: 20 },
  { name: 'S', val: 10 },
];

export const DashboardScreen: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark text-white pb-24">
      <header className="flex items-center justify-between px-4 py-3 sticky top-0 bg-bg-dark/95 backdrop-blur z-20">
         <button onClick={() => navigate('/agenda')} className="size-10 flex items-center justify-center rounded-full hover:bg-white/10">
            <span className="material-symbols-outlined">arrow_back</span>
         </button>
         <h1 className="text-lg font-bold">Productivity Dashboard</h1>
         <div className="size-10"></div>
      </header>

      <div className="p-4 flex flex-col gap-6">
         <section className="flex flex-col p-6 rounded-3xl bg-primary text-white shadow-lg relative overflow-hidden">
            <div className="absolute right-[-20px] top-[-20px] w-32 h-32 bg-accent/20 rounded-full blur-2xl"></div>
            <div className="relative z-10">
               <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium text-slate-300">This Week's Goal</span>
                  <div className="flex items-center gap-1 text-accent text-xs font-semibold bg-accent/10 px-2 py-1 rounded-full">
                     <span className="material-symbols-outlined text-[14px]">trending_up</span> On Track
                  </div>
               </div>
               <div className="flex items-baseline gap-2 mb-6">
                  <span className="text-4xl font-bold">38</span>
                  <span className="text-xl text-slate-400">/ 45 Tasks</span>
               </div>
               <div className="space-y-2">
                  <div className="flex justify-between text-xs text-slate-300">
                     <span>84% Completed</span>
                     <span>7 Tasks Remaining</span>
                  </div>
                  <div className="h-3 w-full bg-slate-700/50 rounded-full overflow-hidden">
                     <div className="h-full bg-gradient-to-r from-accent to-cyan-300 w-[84%] rounded-full shadow-[0_0_12px_rgba(25,195,230,0.6)]"></div>
                  </div>
               </div>
            </div>
         </section>

         <section>
             <h2 className="text-base font-bold mb-4">Daily Activity</h2>
             <div className="bg-primary rounded-3xl p-5 border border-white/5 h-64">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={data}>
                      <Bar dataKey="val" radius={[4, 4, 0, 0]}>
                        {data.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 2 ? '#19c3e6' : '#284e57'} />
                        ))}
                      </Bar>
                   </BarChart>
                </ResponsiveContainer>
             </div>
         </section>

         <section className="grid grid-cols-2 gap-4">
             <div className="bg-primary p-5 rounded-3xl border border-white/5 h-40 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                   <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                      <span className="material-symbols-outlined">timer</span>
                   </div>
                   <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded-full">12%</span>
                </div>
                <div>
                   <h4 className="text-2xl font-bold">45m</h4>
                   <p className="text-[11px] text-slate-400 uppercase tracking-wide mt-1">Avg Resolution</p>
                </div>
             </div>
             <div className="bg-primary p-5 rounded-3xl border border-white/5 h-40 flex flex-col justify-between">
                <div className="flex justify-between items-start">
                   <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl">
                      <span className="material-symbols-outlined filled">star</span>
                   </div>
                </div>
                <div>
                   <div className="flex items-center gap-1">
                      <h4 className="text-2xl font-bold">4.8</h4>
                      <span className="material-symbols-outlined text-amber-400 text-sm filled">star</span>
                   </div>
                   <p className="text-[11px] text-slate-400 uppercase tracking-wide mt-1">Cust. Rating</p>
                </div>
             </div>
         </section>
      </div>
      <BottomNav />
    </div>
  );
};
