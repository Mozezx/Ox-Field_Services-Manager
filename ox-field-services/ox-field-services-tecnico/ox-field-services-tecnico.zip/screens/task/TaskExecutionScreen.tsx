import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const TaskExecutionScreen: React.FC = () => {
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([
    { id: 1, text: 'Inspect main HVAC unit pressure', done: true },
    { id: 2, text: 'Replace air intake filter (#402A)', done: true },
    { id: 3, text: 'Calibrate thermostat sensors', done: true },
    { id: 4, text: 'Verify Safety Lockout', done: false },
    { id: 5, text: 'Clean surrounding area', done: false },
  ]);

  const toggleTask = (id: number) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  return (
    <div className="min-h-screen bg-bg-dark pb-24">
      <header className="sticky top-0 z-20 flex items-center bg-bg-dark/95 backdrop-blur-sm px-4 py-3 justify-between border-b border-slate-800">
        <button onClick={() => navigate('/agenda')} className="flex size-10 items-center justify-center rounded-full hover:bg-slate-800 transition-colors text-white">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h2 className="text-white text-lg font-bold flex-1 text-center">Execution</h2>
        <div className="size-10"></div>
      </header>

      <div className="p-4 flex flex-col gap-6">
         {/* Map Placeholder */}
         <div className="relative w-full h-48 bg-slate-800 rounded-2xl overflow-hidden border border-slate-700">
             <div className="absolute inset-0 bg-[url('https://picsum.photos/id/10/600/300')] bg-cover opacity-50"></div>
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-primary/90 p-3 rounded-full border-2 border-accent animate-bounce">
                   <span className="material-symbols-outlined text-accent text-2xl">navigation</span>
                </div>
             </div>
             <div className="absolute bottom-3 left-3 bg-black/70 px-3 py-1 rounded-lg backdrop-blur text-xs font-bold text-white">
                124 Industrial Ave
             </div>
             <button className="absolute bottom-3 right-3 bg-accent text-primary px-3 py-1 rounded-lg text-xs font-bold">
                ARRIVED
             </button>
         </div>

         {/* Tasks */}
         <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
               <h3 className="text-lg font-bold text-white">Checklist</h3>
               <span className="text-xs font-medium text-accent bg-accent/10 px-2 py-1 rounded">{tasks.filter(t => t.done).length}/{tasks.length} Done</span>
            </div>
            <div className="bg-surface-dark rounded-xl border border-slate-800 divide-y divide-slate-800">
               {tasks.map(task => (
                 <div key={task.id} onClick={() => toggleTask(task.id)} className="flex items-center gap-3 p-4 cursor-pointer hover:bg-white/5 transition-colors">
                    <div className={`flex items-center justify-center size-6 rounded-md border ${task.done ? 'bg-secondary border-secondary text-primary' : 'border-slate-500'}`}>
                       {task.done && <span className="material-symbols-outlined text-sm font-bold">check</span>}
                    </div>
                    <span className={`text-sm font-medium ${task.done ? 'text-slate-400 line-through' : 'text-white'}`}>{task.text}</span>
                 </div>
               ))}
            </div>
         </div>

         {/* Photos */}
         <div className="flex flex-col gap-2">
             <div className="flex items-center justify-between">
               <h3 className="text-lg font-bold text-white">Photo Evidence</h3>
               <button className="text-xs font-bold text-accent flex items-center gap-1">
                 <span className="material-symbols-outlined text-sm">add_a_photo</span> ADD
               </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
               {[1, 2].map(i => (
                  <div key={i} className="aspect-square bg-slate-800 rounded-lg relative overflow-hidden group">
                     <img src={`https://picsum.photos/id/${i+50}/200/200`} className="w-full h-full object-cover" alt="Evidence" />
                     <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="material-symbols-outlined text-white">visibility</span>
                     </div>
                  </div>
               ))}
               <button className="aspect-square bg-slate-800 rounded-lg border-2 border-dashed border-slate-600 flex flex-col items-center justify-center gap-1 hover:border-accent hover:text-accent text-slate-500 transition-all">
                  <span className="material-symbols-outlined">add</span>
                  <span className="text-[10px] font-bold uppercase">Photo</span>
               </button>
            </div>
         </div>

         <button onClick={() => navigate('/task/4092/materials')} className="w-full py-4 bg-surface-dark border border-slate-700 rounded-xl flex items-center justify-between px-4 hover:bg-slate-800">
            <div className="flex items-center gap-3">
               <span className="material-symbols-outlined text-accent">inventory_2</span>
               <span className="font-bold text-white">Materials Used</span>
            </div>
            <span className="material-symbols-outlined text-slate-400">chevron_right</span>
         </button>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-bg-dark border-t border-slate-800 z-30">
        <button onClick={() => navigate('/task/4092/complete')} className="w-full bg-secondary hover:bg-green-400 text-primary font-bold h-12 rounded-xl flex items-center justify-center gap-2">
           Complete Task <span className="material-symbols-outlined">arrow_forward</span>
        </button>
      </div>
    </div>
  );
};
