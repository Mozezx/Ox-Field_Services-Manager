import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const ServiceCompletionScreen: React.FC = () => {
  const navigate = useNavigate();
  const [signature, setSignature] = useState(false);

  return (
    <div className="min-h-screen bg-bg-dark flex flex-col text-white pb-24">
      <header className="flex items-center justify-between px-4 py-3 bg-bg-dark border-b border-slate-800">
         <button onClick={() => navigate('/task/4092')} className="h-10 w-10 flex items-center justify-center rounded-full hover:bg-white/10 text-white">
          <span className="material-symbols-outlined">arrow_back</span>
         </button>
         <h1 className="text-base font-bold uppercase tracking-wide">Service Completion</h1>
         <button onClick={() => navigate('/agenda')} className="text-sm text-slate-400 hover:text-red-400">Cancel</button>
      </header>

      <div className="p-5 flex flex-col gap-6">
         <section>
            <div className="flex justify-between mb-3 px-1">
               <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Proof of Work</h2>
               <span className="text-xs text-slate-500">3/5 Photos</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
               {[1, 2].map(i => (
                  <div key={i} className="aspect-square rounded-xl bg-surface-dark relative overflow-hidden group">
                     <img src={`https://picsum.photos/id/${i+60}/200/200`} className="w-full h-full object-cover" />
                     <div className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="material-symbols-outlined text-xs">close</span>
                     </div>
                  </div>
               ))}
               <button className="aspect-square rounded-xl border-2 border-dashed border-slate-700 bg-surface-dark flex flex-col items-center justify-center gap-2 text-slate-500 hover:border-accent hover:text-accent transition-colors">
                  <div className="size-8 rounded-full bg-slate-800 flex items-center justify-center">
                     <span className="material-symbols-outlined">add_a_photo</span>
                  </div>
                  <span className="text-[10px] font-bold uppercase">Add Photo</span>
               </button>
            </div>
         </section>

         <div className="h-px bg-slate-800"></div>

         <section>
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Client Authorization</h2>
            <div className="bg-surface-dark rounded-2xl p-5 border border-slate-800">
               <p className="text-sm text-slate-300 mb-4 leading-relaxed">
                  I acknowledge that the service has been completed to satisfaction and verify the above work.
               </p>
               <div className="w-full h-40 bg-slate-200 rounded-xl border-2 border-transparent relative overflow-hidden cursor-crosshair mb-5" onClick={() => setSignature(true)}>
                  {!signature && (
                     <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <span className="text-slate-400 text-3xl font-bold uppercase opacity-50">Sign Here</span>
                     </div>
                  )}
                  {signature && (
                      <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 400 200">
                        <path d="M 50 100 Q 80 80 100 120 T 150 100 Q 180 60 200 110 T 250 90 Q 280 130 320 80" fill="none" stroke="#0f172a" strokeWidth="3" />
                      </svg>
                  )}
                  <button onClick={(e) => { e.stopPropagation(); setSignature(false); }} className="absolute top-2 right-2 text-[10px] bg-white/80 px-2 py-1 rounded text-slate-500">Clear</button>
               </div>
               
               <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider ml-1">Client Full Name</label>
                  <div className="relative">
                     <span className="absolute left-3 top-3 material-symbols-outlined text-slate-500 text-lg">person</span>
                     <input type="text" defaultValue="Sarah Jenkins" className="block w-full pl-10 bg-black/20 border border-slate-700 rounded-xl text-sm text-white py-3 focus:ring-accent" />
                  </div>
               </div>
            </div>
         </section>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-surface-dark/90 backdrop-blur border-t border-slate-800 z-40">
         <div className="flex items-center justify-center gap-2 mb-3">
            <span className="relative flex h-2 w-2">
               <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary opacity-75"></span>
               <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary"></span>
            </span>
            <span className="text-xs font-semibold text-slate-400">Online & Ready to Sync</span>
         </div>
         <button onClick={() => navigate('/agenda')} className="w-full h-14 bg-primary hover:bg-[#0f2e36] text-white font-bold text-base rounded-xl shadow-lg border border-secondary flex items-center justify-center gap-3">
            FINISH SERVICE & SYNC <span className="material-symbols-outlined text-secondary">cloud_upload</span>
         </button>
      </div>
    </div>
  );
};
