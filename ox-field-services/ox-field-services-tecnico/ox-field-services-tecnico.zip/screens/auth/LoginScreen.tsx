import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const LoginScreen: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate('/agenda');
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-bg-dark flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 opacity-[0.05] bg-[url('https://picsum.photos/id/20/1000/1000')] bg-cover mix-blend-overlay"></div>
      
      <div className="relative z-10 w-full max-w-lg">
        <div className="flex flex-col items-center mb-10">
          <div className="relative mb-6 group cursor-pointer">
             <div className="absolute inset-0 bg-secondary/20 rounded-2xl blur-lg"></div>
             <div className="relative w-24 h-24 bg-gradient-to-br from-primary to-[#0f2e36] rounded-2xl flex items-center justify-center shadow-2xl border border-white/10">
                <span className="material-symbols-outlined text-5xl text-white filled">agriculture</span>
             </div>
          </div>
          <h1 className="text-3xl font-bold text-white text-center">Ox Field Services</h1>
          <div className="flex items-center gap-2 mt-2">
            <div className="h-px w-8 bg-slate-600"></div>
            <span className="text-xs font-bold tracking-[0.2em] text-slate-400 uppercase">Technician Portal</span>
            <div className="h-px w-8 bg-slate-600"></div>
          </div>
        </div>

        <form onSubmit={handleLogin} className="flex flex-col gap-5">
          <div className="flex flex-col gap-2">
            <label className="text-sm font-semibold text-slate-300 ml-1">Technician ID / Email</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="material-symbols-outlined text-slate-500 group-focus-within:text-white transition-colors">badge</span>
              </div>
              <input 
                type="text" 
                placeholder="Enter your ID" 
                className="block w-full rounded-lg border-0 py-4 pl-12 pr-4 text-white bg-[#1e2325] ring-1 ring-inset ring-slate-700 placeholder:text-slate-600 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-base shadow-sm transition-all"
              />
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center ml-1">
              <label className="text-sm font-semibold text-slate-300">Password</label>
            </div>
            <div className="relative group">
               <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="material-symbols-outlined text-slate-500 group-focus-within:text-white transition-colors">lock</span>
              </div>
              <input 
                type="password" 
                placeholder="Enter password" 
                className="block w-full rounded-lg border-0 py-4 pl-12 pr-12 text-white bg-[#1e2325] ring-1 ring-inset ring-slate-700 placeholder:text-slate-600 focus:ring-2 focus:ring-inset focus:ring-secondary sm:text-base shadow-sm transition-all"
              />
               <button type="button" className="absolute inset-y-0 right-0 flex items-center pr-4 text-slate-500 hover:text-white">
                <span className="material-symbols-outlined">visibility</span>
              </button>
            </div>
             <div className="flex justify-end">
              <a href="#" className="text-xs font-medium text-slate-400 hover:text-white underline underline-offset-4">Forgot Password?</a>
            </div>
          </div>

          <div className="mt-4 flex gap-3">
            <button 
              type="submit" 
              className="flex-1 rounded-lg bg-white text-primary px-4 py-4 text-base font-bold shadow-lg hover:bg-slate-100 uppercase tracking-wider transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              {loading ? 'Logging in...' : 'Log In'}
              {!loading && <span className="material-symbols-outlined text-sm font-bold">arrow_forward</span>}
            </button>
            <button type="button" className="aspect-square h-auto rounded-lg bg-[#1e2325] p-3 text-white ring-1 ring-inset ring-slate-700 hover:bg-[#252b2d] active:scale-95 transition-all flex items-center justify-center">
               <span className="material-symbols-outlined text-2xl">face</span>
            </button>
          </div>
        </form>

        <div className="mt-8 flex justify-center">
             <button onClick={() => navigate('/register/1')} className="text-sm text-slate-400 hover:text-white transition-colors">
                New Technician? <span className="text-secondary font-bold">Create Account</span>
             </button>
        </div>

        <div className="mt-12 flex flex-col items-center gap-6 w-full">
          <button className="group flex items-center gap-3 px-5 py-3 rounded-full bg-[#1e2325]/50 border border-transparent hover:border-slate-700 transition-all">
            <div className="p-1.5 rounded-full bg-[#252b2d] shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
               <span className="material-symbols-outlined text-lg text-slate-400">headset_mic</span>
            </div>
            <span className="text-sm font-medium text-slate-400 group-hover:text-white">Contact Dispatch Support</span>
          </button>
          <div className="flex flex-col items-center gap-1 opacity-50">
            <p className="text-[10px] font-mono text-slate-600 uppercase tracking-widest">Version 2.4.1</p>
          </div>
        </div>
      </div>
    </div>
  );
};
