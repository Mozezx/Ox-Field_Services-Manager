import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const StepHeader: React.FC<{ step: number; title: string; subtitle: string }> = ({ step, title, subtitle }) => (
  <div className="mb-6">
    <div className="flex items-center justify-between mb-2">
      <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Step {step} of 3</span>
    </div>
    <div className="flex w-full gap-2 h-1.5 mb-6">
      <div className={`h-full flex-1 rounded-full ${step >= 1 ? 'bg-secondary' : 'bg-slate-700'}`}></div>
      <div className={`h-full flex-1 rounded-full ${step >= 2 ? 'bg-secondary' : 'bg-slate-700'}`}></div>
      <div className={`h-full flex-1 rounded-full ${step >= 3 ? 'bg-secondary' : 'bg-slate-700'}`}></div>
    </div>
    <h1 className="text-3xl font-bold leading-tight tracking-tight mb-2 text-white">{title}</h1>
    <p className="text-base text-slate-400">{subtitle}</p>
  </div>
);

export const RegisterStep1: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark flex flex-col p-6">
      <header className="flex items-center mb-6">
        <button onClick={() => navigate('/')} className="h-10 w-10 flex items-center justify-center rounded-full hover:bg-white/10 text-white">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
      </header>
      <StepHeader step={1} title="Personal Info" subtitle="Enter details to register as a new technician." />
      
      <form className="flex flex-col gap-5 flex-1">
        {['Full Name', 'CPF', 'Mobile Phone', 'Email Address'].map((label, idx) => (
           <div key={label} className="space-y-1.5">
            <label className="text-sm font-medium text-slate-300 ml-1">{label}</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <span className="material-symbols-outlined text-slate-500">
                  {idx === 0 ? 'person' : idx === 1 ? 'id_card' : idx === 2 ? 'smartphone' : 'mail'}
                </span>
              </div>
              <input type={idx === 3 ? 'email' : 'text'} className="block w-full rounded-lg border border-slate-700 bg-surface-dark text-white pl-11 pr-4 py-3.5 focus:border-secondary focus:ring-secondary" placeholder={`Enter ${label}`} />
            </div>
           </div>
        ))}
      </form>

      <button onClick={() => navigate('/register/2')} className="w-full h-14 rounded-full bg-white text-primary text-base font-bold mt-6 flex items-center justify-center gap-2">
        Continue <span className="material-symbols-outlined">arrow_forward</span>
      </button>
    </div>
  );
};

export const RegisterStep2: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark flex flex-col p-6">
      <header className="flex items-center mb-6">
        <button onClick={() => navigate('/register/1')} className="h-10 w-10 flex items-center justify-center rounded-full hover:bg-white/10 text-white">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
      </header>
      <StepHeader step={2} title="Verify Identity" subtitle="Upload clear photos of your documents." />
      
      <div className="flex flex-col gap-4 flex-1">
        {[1, 2].map((i) => (
          <button key={i} className="group flex w-full flex-col items-center gap-4 rounded-xl border-2 border-dashed border-slate-700 bg-surface-dark py-8 hover:border-white transition-all">
             <div className="flex size-14 items-center justify-center rounded-full bg-slate-800 group-hover:bg-slate-700">
                <span className="material-symbols-outlined text-white text-2xl">photo_camera</span>
             </div>
             <div className="text-center">
               <p className="text-white font-bold">Government ID ({i === 1 ? 'Front' : 'Back'})</p>
               <p className="text-slate-500 text-sm">Tap to capture</p>
             </div>
          </button>
        ))}
         <div className="flex w-full items-center gap-4 rounded-xl border border-slate-700 bg-surface-dark p-4">
             <div className="size-16 rounded-lg bg-slate-800 flex items-center justify-center">
                <span className="material-symbols-outlined text-slate-500">description</span>
             </div>
             <div className="flex-1">
                <p className="text-white font-bold">Electrician_Cert.jpg</p>
                <p className="text-secondary text-sm flex items-center gap-1">
                   <span className="material-symbols-outlined text-sm">check_circle</span> Uploaded
                </p>
             </div>
             <button className="text-slate-500 hover:text-red-400"><span className="material-symbols-outlined">delete</span></button>
         </div>
      </div>

      <button onClick={() => navigate('/register/3')} className="w-full h-14 rounded-full bg-white text-primary text-base font-bold mt-6 flex items-center justify-center gap-2">
        Next Step <span className="material-symbols-outlined">arrow_forward</span>
      </button>
    </div>
  );
};

export const RegisterStep3: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark flex flex-col p-6">
      <header className="flex items-center mb-6">
        <button onClick={() => navigate('/register/2')} className="h-10 w-10 flex items-center justify-center rounded-full hover:bg-white/10 text-white">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
      </header>
      <StepHeader step={3} title="Specialties" subtitle="Select your expertise." />
      
      <div className="flex-1 overflow-y-auto no-scrollbar">
         <div className="relative mb-4">
            <span className="material-symbols-outlined absolute left-3 top-3.5 text-slate-500">search</span>
            <input type="text" placeholder="Search trades..." className="w-full bg-surface-dark border-none rounded-lg py-3 pl-10 text-white" />
         </div>
         
         <div className="space-y-2">
            {['Electrical', 'HVAC', 'Plumbing', 'Carpentry', 'Low Voltage', 'Appliance Repair'].map((trade) => (
               <label key={trade} className="flex items-center justify-between p-4 bg-surface-dark rounded-lg cursor-pointer border border-transparent hover:border-slate-600">
                  <div className="flex items-center gap-3">
                     <div className="p-2 rounded-full bg-slate-800 text-secondary">
                        <span className="material-symbols-outlined text-xl">
                            {trade === 'Electrical' ? 'bolt' : trade === 'HVAC' ? 'ac_unit' : trade === 'Plumbing' ? 'water_drop' : 'handyman'}
                        </span>
                     </div>
                     <span className="text-white font-medium">{trade}</span>
                  </div>
                  <input type="checkbox" className="size-6 rounded border-slate-600 bg-transparent text-secondary focus:ring-secondary" defaultChecked={trade === 'HVAC'} />
               </label>
            ))}
         </div>
      </div>

      <button onClick={() => navigate('/approval')} className="w-full h-14 rounded-full bg-secondary text-primary text-base font-bold mt-6 flex items-center justify-center gap-2">
        Finish Application <span className="material-symbols-outlined">check</span>
      </button>
    </div>
  );
};

export const ApprovalScreen: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-bg-dark flex flex-col items-center justify-center p-6 text-center">
       <div className="relative mb-8">
          <div className="absolute inset-0 bg-secondary/20 rounded-full blur-2xl transform scale-150 opacity-50"></div>
          <div className="relative size-32 rounded-full bg-[#1e282b] border-4 border-[#2b3436] flex items-center justify-center shadow-xl">
             <span className="material-symbols-outlined text-6xl text-white animate-pulse">pending</span>
          </div>
          <div className="absolute bottom-0 right-0 bg-[#2b3436] border-4 border-bg-dark rounded-full p-2 flex items-center justify-center">
             <span className="material-symbols-outlined text-xl text-yellow-500">hourglass_top</span>
          </div>
       </div>
       <h1 className="text-3xl font-bold text-white mb-3">Awaiting Approval</h1>
       <p className="text-slate-400 max-w-xs mb-8">Your registration was successful. We are validating your data. You will receive an email once activated.</p>
       
       <button onClick={() => navigate('/login')} className="text-slate-400 hover:text-white underline">Back to Login</button>
    </div>
  );
};
