import React from 'react';
import { useNavigate } from 'react-router-dom';
import { BottomNav } from '../../components/BottomNav';

export const AgendaScreen: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-bg-dark pb-24">
      <header className="sticky top-0 z-20 flex items-center justify-between bg-bg-dark/95 backdrop-blur-md p-4 border-b border-white/10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/notifications')} className="relative text-slate-300 hover:text-white">
            <span className="material-symbols-outlined text-3xl">notifications</span>
            <span className="absolute top-0 right-0 size-2.5 bg-red-500 rounded-full border border-bg-dark"></span>
          </button>
          <div>
            <h1 className="text-xl font-bold text-white">My Agenda</h1>
            <div className="flex items-center gap-1.5">
               <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="text-xs text-slate-400 font-medium">Online • Synced</span>
            </div>
          </div>
        </div>
        <button className="h-10 w-10 rounded-full overflow-hidden border-2 border-slate-700" onClick={() => navigate('/profile')}>
           <img src="https://picsum.photos/id/64/200/200" alt="Profile" className="h-full w-full object-cover" />
        </button>
      </header>

      <div className="px-4 py-6">
         <h2 className="text-2xl font-bold text-white">Good Morning, Alex</h2>
         <p className="text-slate-400 text-sm mt-1">Oct 24, 2023 • Tuesday</p>
      </div>

      <div className="px-4 mb-6">
        <div className="bg-surface-dark rounded-xl p-4 border border-slate-800">
          <div className="flex justify-between items-end mb-2">
             <p className="text-sm font-semibold text-slate-200">Daily Progress</p>
             <p className="text-xs font-medium text-slate-400">2/5 Jobs Completed</p>
          </div>
          <div className="h-2.5 w-full rounded-full bg-slate-700 overflow-hidden">
             <div className="h-full bg-secondary w-[40%] rounded-full"></div>
          </div>
        </div>
      </div>

      <div className="px-4 mb-8">
        <div className="flex items-center justify-between mb-3">
           <h3 className="text-lg font-bold text-white">Current Task</h3>
           <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-accent/20 text-accent border border-accent/30 animate-pulse">Live</span>
        </div>
        
        <div 
          onClick={() => navigate('/task/4092')}
          className="relative overflow-hidden rounded-2xl bg-[#18363e] border border-accent/30 shadow-lg cursor-pointer active:scale-[0.99] transition-transform"
        >
           <div className="p-5 flex flex-col gap-4 relative z-10">
              <div className="flex flex-col">
                 <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-accent/80">OS #4092</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/20 text-red-300 border border-red-500/30">HIGH PRIORITY</span>
                 </div>
                 <h4 className="text-xl font-bold text-white leading-tight">HVAC System Repair</h4>
              </div>
              
              <div className="flex items-center gap-3 py-2">
                 <div className="p-2 rounded-lg bg-black/20 text-accent">
                    <span className="material-symbols-outlined text-2xl">timer</span>
                 </div>
                 <div className="flex flex-col">
                    <span className="text-[10px] uppercase text-slate-400 font-semibold tracking-wider">Time Elapsed</span>
                    <span className="text-3xl font-mono font-bold text-white tracking-widest tabular-nums">00:45:12</span>
                 </div>
              </div>

              <div className="flex items-start gap-3 bg-black/20 p-3 rounded-lg border border-white/5">
                 <span className="material-symbols-outlined text-slate-400 mt-0.5 text-lg">location_on</span>
                 <div className="flex flex-col">
                    <span className="text-white font-medium text-sm">124 Industrial Ave, Sector 4</span>
                    <span className="text-slate-400 text-xs mt-0.5">Building B, Floor 2 • 3.2 mi away</span>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-1">
                 <button onClick={(e) => { e.stopPropagation(); }} className="flex items-center justify-center gap-2 py-3 rounded-lg bg-white/10 hover:bg-white/15 text-white font-semibold">
                    <span className="material-symbols-outlined">pause</span> Pause
                 </button>
                 <button onClick={(e) => { e.stopPropagation(); navigate('/task/4092/complete'); }} className="flex items-center justify-center gap-2 py-3 rounded-lg bg-secondary hover:bg-secondary/90 text-primary font-bold">
                    <span className="material-symbols-outlined">check_circle</span> Complete
                 </button>
              </div>
           </div>
        </div>
      </div>

      <div className="px-4">
         <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-bold text-white">Up Next</h3>
            <span className="text-sm text-slate-400">3 Jobs</span>
         </div>
         <div className="flex flex-col gap-3">
            {[
              { id: '4093', title: 'Routine Maintenance', time: '14:00', priority: 'MEDIUM', color: 'orange' },
              { id: '4094', title: 'Fiber Optic Installation', time: '16:00', priority: 'LOW', color: 'blue' },
              { id: '4095', title: 'Equipment Pickup', time: '17:30', priority: 'LOW', color: 'slate' }
            ].map(job => (
              <div key={job.id} className="p-4 rounded-xl bg-surface-dark border border-slate-800 flex flex-col gap-2 active:scale-[0.99] transition-transform">
                 <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                       <span className="text-xs font-mono text-slate-400">OS #{job.id}</span>
                       <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border bg-${job.color}-500/10 text-${job.color}-400 border-${job.color}-500/20`}>{job.priority}</span>
                    </div>
                    <div className="flex items-center gap-1 text-slate-400">
                       <span className="material-symbols-outlined text-base">schedule</span>
                       <span className="text-xs font-semibold">{job.time}</span>
                    </div>
                 </div>
                 <h4 className="text-base font-bold text-white">{job.title}</h4>
                 <div className="flex items-center gap-2 text-slate-400 text-sm">
                    <span className="material-symbols-outlined text-base">location_on</span>
                    <span className="truncate">Springfield, IL</span>
                 </div>
              </div>
            ))}
         </div>
      </div>
      
      <button onClick={() => navigate('/chat')} className="fixed bottom-24 right-4 z-30 h-14 w-14 rounded-full bg-accent text-primary shadow-lg hover:scale-105 transition-all flex items-center justify-center">
         <span className="material-symbols-outlined text-3xl">support_agent</span>
      </button>

      <BottomNav />
    </div>
  );
};
