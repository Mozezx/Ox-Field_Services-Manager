import React from 'react';
import { 
  Eye, 
  MoreHorizontal, 
  Filter, 
  Download,
  Plus
} from 'lucide-react';
import { MOCK_TENANTS } from '../constants';
import { Tenant, TenantStatus } from '../types';

interface TenantProps {
  onImpersonate: (tenant: Tenant) => void;
}

const TenantManagement: React.FC<TenantProps> = ({ onImpersonate }) => {
  
  const getStatusColor = (status: TenantStatus) => {
    switch (status) {
      case TenantStatus.ACTIVE: return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case TenantStatus.SUSPENDED: return 'bg-red-500/10 text-red-400 border-red-500/20';
      case TenantStatus.PROVISIONING: return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case TenantStatus.DELINQUENT: return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      default: return 'bg-slate-700 text-slate-300';
    }
  };

  return (
    <div className="p-6 lg:p-8 max-w-[1600px] mx-auto h-full flex flex-col">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Tenant Management</h1>
          <p className="text-slate-400 mt-1">Manage global instances, access control, and onboarding.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-dark-800 hover:bg-dark-700 text-slate-300 rounded border border-dark-700 text-sm transition-colors">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-ox-900 hover:bg-ox-800 text-white font-medium rounded border border-ox-700 text-sm transition-colors shadow-lg shadow-ox-900/20">
            <Plus className="h-4 w-4" />
            New Tenant
          </button>
        </div>
      </div>

      <div className="bg-dark-900 border border-dark-800 rounded-lg flex flex-col flex-1 overflow-hidden shadow-xl">
        {/* Toolbar */}
        <div className="p-4 border-b border-dark-800 flex items-center justify-between gap-4 bg-dark-800/50">
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 bg-dark-800 text-slate-300 text-xs font-medium rounded border border-dark-700 flex items-center gap-2 hover:text-white">
              <Filter className="h-3 w-3" /> Filter
            </button>
            <div className="h-6 w-px bg-dark-700 mx-2"></div>
            <span className="text-sm text-slate-400">Showing <span className="text-white font-mono">{MOCK_TENANTS.length}</span> tenants</span>
          </div>
          <div className="flex gap-2">
             <span className="text-xs text-ox-500 font-medium cursor-pointer hover:underline">New Requests (2)</span>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-left border-collapse">
            <thead className="bg-dark-950 text-slate-500 text-xs uppercase tracking-wider font-semibold sticky top-0 z-10">
              <tr>
                <th className="px-6 py-4 border-b border-dark-700">Tenant Name</th>
                <th className="px-6 py-4 border-b border-dark-700">Status</th>
                <th className="px-6 py-4 border-b border-dark-700">Region</th>
                <th className="px-6 py-4 border-b border-dark-700 text-right">Users</th>
                <th className="px-6 py-4 border-b border-dark-700 text-right">MRR</th>
                <th className="px-6 py-4 border-b border-dark-700">Health</th>
                <th className="px-6 py-4 border-b border-dark-700 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-800 text-sm">
              {MOCK_TENANTS.map((tenant) => (
                <tr key={tenant.id} className="group hover:bg-dark-800/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded bg-dark-800 flex items-center justify-center text-slate-400 text-xs font-bold border border-dark-700 group-hover:border-ox-700 group-hover:text-ox-400 transition-colors">
                        {tenant.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-white group-hover:text-ox-400 transition-colors">{tenant.name}</div>
                        <div className="text-xs text-slate-500 font-mono">{tenant.domain}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(tenant.status)}`}>
                      {tenant.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-400 font-mono text-xs">
                    {tenant.region}
                  </td>
                  <td className="px-6 py-4 text-right text-slate-300 font-mono">
                    {tenant.users.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-right text-slate-300 font-mono">
                    ${tenant.mrr.toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-dark-800 rounded-full overflow-hidden w-24">
                        <div 
                          className={`h-full rounded-full ${
                            tenant.healthScore > 90 ? 'bg-emerald-500' : 
                            tenant.healthScore > 60 ? 'bg-amber-500' : 'bg-red-500'
                          }`} 
                          style={{ width: `${tenant.healthScore}%` }}
                        />
                      </div>
                      <span className="text-xs text-slate-500 w-8 text-right">{tenant.healthScore}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => onImpersonate(tenant)}
                        className="p-1.5 text-slate-400 hover:text-white hover:bg-dark-700 rounded transition-colors group/btn"
                        title="Impersonate"
                      >
                        <Eye className="h-4 w-4 group-hover/btn:text-ox-400" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-dark-700 rounded transition-colors">
                        <MoreHorizontal className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="p-4 border-t border-dark-800 bg-dark-800/30 flex items-center justify-between text-xs text-slate-500">
          <span>Showing 1-6 of 142 tenants</span>
          <div className="flex gap-2">
            <button className="px-3 py-1 rounded bg-dark-800 border border-dark-700 hover:text-white disabled:opacity-50">Prev</button>
            <button className="px-3 py-1 rounded bg-dark-800 border border-dark-700 hover:text-white">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TenantManagement;