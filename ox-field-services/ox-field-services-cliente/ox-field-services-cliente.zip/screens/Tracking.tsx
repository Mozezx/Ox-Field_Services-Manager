import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export const Tracking = () => {
  const navigate = useNavigate();
  const { setActiveService } = useApp();
  const [timeLeft, setTimeLeft] = useState(8); // Start at 8 mins

  // Simulate travel and arrival
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate('/rating');
          return 0;
        }
        return prev - 1;
      });
    }, 1000); // Fast forward time for demo (1s = 1min approximately)

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div className="relative h-screen w-full bg-background-dark overflow-hidden flex flex-col">
      {/* Map Background (Simulated) */}
      <div className="absolute inset-0 z-0 opacity-60">
        <img 
          src="https://picsum.photos/800/1200?grayscale&blur=2" 
          alt="Map" 
          className="w-full h-full object-cover invert" 
        />
        <div className="absolute inset-0 bg-primary/20 mix-blend-overlay"></div>
      </div>

      {/* Floating Header */}
      <div className="relative z-10 pt-12 px-4 flex justify-between items-center">
        <button onClick={() => navigate('/home')} className="size-10 rounded-full bg-surface-dark shadow-lg flex items-center justify-center text-white">
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <div className="bg-surface-dark/90 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
          <span className="text-sm font-bold text-white">Technician En Route</span>
        </div>
        <button className="size-10 rounded-full bg-surface-dark shadow-lg flex items-center justify-center text-white">
          <span className="material-symbols-outlined">my_location</span>
        </button>
      </div>

      {/* Technician Marker Simulation */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-0">
        <div className="relative">
          <div className="size-16 rounded-full bg-primary/30 animate-ping absolute inset-0"></div>
          <div className="size-16 rounded-full bg-primary border-4 border-white shadow-xl flex items-center justify-center z-10 relative">
             <span className="material-symbols-outlined text-white text-3xl">local_shipping</span>
          </div>
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-surface-dark px-2 py-1 rounded text-xs font-bold text-white whitespace-nowrap">
            Mike • {timeLeft} min
          </div>
        </div>
      </div>

      <div className="flex-1"></div>

      {/* Bottom Sheet */}
      <div className="relative z-20 bg-surface-dark rounded-t-[2rem] p-6 shadow-2xl border-t border-white/5 animate-slide-up">
        <div className="w-12 h-1.5 bg-gray-600 rounded-full mx-auto mb-6"></div>
        
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white">Arriving in {timeLeft} mins</h2>
            <p className="text-gray-400 text-sm">10:00 AM • On Time</p>
          </div>
          <div className="bg-green-500/20 text-accent px-3 py-1 rounded-full text-xs font-bold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span>
            LIVE
          </div>
        </div>

        <div className="flex items-center gap-4 bg-background-dark p-4 rounded-2xl border border-white/5 mb-6">
          <div className="relative">
             <img src="https://i.pravatar.cc/150?u=mike" alt="Tech" className="w-14 h-14 rounded-full border-2 border-surface-dark" />
             <div className="absolute -bottom-1 -right-1 bg-primary text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border border-surface-dark">4.9 ★</div>
          </div>
          <div className="flex-1">
             <h3 className="text-white font-bold">Mike R.</h3>
             <p className="text-gray-400 text-xs">HVAC Senior Tech</p>
          </div>
          <div className="flex gap-2">
             <button onClick={() => navigate('/support')} className="size-10 rounded-full bg-surface-dark border border-white/10 flex items-center justify-center text-white hover:bg-white/5">
                <span className="material-symbols-outlined text-[20px]">chat_bubble</span>
             </button>
             <button className="size-10 rounded-full bg-accent flex items-center justify-center text-primary shadow-lg hover:brightness-110">
                <span className="material-symbols-outlined text-[20px]">call</span>
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};