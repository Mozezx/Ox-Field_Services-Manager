import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export const Confirmation = () => {
  const navigate = useNavigate();
  const { addService } = useApp();
  const [searchParams] = useSearchParams();
  const type = searchParams.get('type') || 'Service';

  const handleGoHome = () => {
    // Register the new service as active
    addService({
      id: `SR-${Math.floor(Math.random() * 10000)}`,
      type: type as any,
      status: 'Pending', // Initially pending, simulating en-route soon
      date: 'Oct 24, 2023',
      time: '10:00 AM',
      address: '123 Maple St',
      technician: {
        id: 'mike',
        name: 'Mike R.',
        role: 'Lead Technician',
        rating: 4.9,
        image: 'https://i.pravatar.cc/150?u=mike'
      }
    });
    navigate('/home');
  };

  return (
    <div className="min-h-screen bg-background-dark flex flex-col p-6 animate-fade-in">
      <div className="flex-1 flex flex-col items-center justify-center gap-6">
        <div className="relative group animate-pulse-slow">
           <div className="absolute inset-0 bg-accent/20 rounded-full blur-xl opacity-50"></div>
           <div className="relative h-28 w-28 rounded-full bg-primary border-4 border-background-dark flex items-center justify-center shadow-2xl">
             <span className="material-symbols-outlined text-accent text-6xl font-bold">check_circle</span>
           </div>
        </div>
        
        <div className="text-center">
          <h1 className="text-white text-3xl font-extrabold mb-2">Booking<br/>Confirmed!</h1>
          <p className="text-gray-400 text-sm">We've sent a receipt to your email.</p>
        </div>

        <div className="w-full bg-card-dark rounded-xl border border-white/5 overflow-hidden mt-4">
          <div className="h-1 w-full bg-gradient-to-r from-transparent via-accent to-transparent opacity-50"></div>
          <div className="p-5 flex flex-col gap-6">
            <div className="flex justify-between items-start">
              <div>
                 <span className="text-xs font-bold uppercase tracking-wider text-gray-500">Service Type</span>
                 <h2 className="text-white text-xl font-bold">{type}</h2>
              </div>
              <div className="px-3 py-1 rounded-full bg-background-dark border border-white/10">
                <p className="text-accent text-xs font-bold">#OX-8821</p>
              </div>
            </div>
            
            <div className="h-px bg-white/10 w-full"></div>
            
            <div className="space-y-4">
               <div className="flex gap-4 items-center">
                  <span className="material-symbols-outlined text-gray-400">calendar_month</span>
                  <div>
                    <p className="text-gray-500 text-xs">Date & Time</p>
                    <p className="text-white text-sm font-semibold">Oct 24, 2023 • 10:00 AM</p>
                  </div>
               </div>
               <div className="flex gap-4 items-center">
                  <span className="material-symbols-outlined text-gray-400">location_on</span>
                  <div>
                    <p className="text-gray-500 text-xs">Address</p>
                    <p className="text-white text-sm font-semibold">123 Maple St, Springfield</p>
                  </div>
               </div>
            </div>

            <div className="h-px bg-white/10 w-full"></div>

            <div className="flex justify-between items-end">
               <div>
                 <p className="text-white text-base font-bold">Estimated Total</p>
                 <p className="text-gray-500 text-[10px]">Final quote on-site</p>
               </div>
               <p className="text-accent text-2xl font-extrabold">$165.00</p>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full space-y-3 mt-8">
        <button className="w-full h-12 rounded-full border border-white/10 text-white font-bold text-sm hover:bg-white/5 transition-colors">
          Add to Calendar
        </button>
        <button onClick={handleGoHome} className="w-full h-12 rounded-full bg-accent text-primary font-bold text-sm hover:brightness-110 shadow-lg shadow-accent/20 transition-all">
          Go to Home
        </button>
      </div>
    </div>
  );
};