import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';

export const Schedule = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const type = searchParams.get('type') || 'General';
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const timeSlots = [
    { id: '08:00', label: '08:00 AM' },
    { id: '10:00', label: '10:00 AM' },
    { id: '13:00', label: '01:00 PM' },
    { id: '15:00', label: '03:00 PM' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background-dark pb-8">
      <header className="px-4 pt-6 pb-2 border-b border-white/5 z-20 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="flex size-10 items-center justify-center rounded-full hover:bg-surface-dark transition-colors">
          <span className="material-symbols-outlined text-white">arrow_back</span>
        </button>
        <h1 className="text-lg font-bold text-white">Schedule Service</h1>
        <div className="size-10"></div>
      </header>

      <main className="flex-1 overflow-y-auto px-4 py-6 no-scrollbar animate-fade-in">
        {/* Calendar Visualization (Static for Demo) */}
        <div className="bg-surface-dark rounded-2xl p-4 border border-white/5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <span className="text-white font-bold">October 2023</span>
            <div className="flex gap-2">
              <button className="p-1 hover:bg-white/10 rounded-full"><span className="material-symbols-outlined text-white">chevron_left</span></button>
              <button className="p-1 hover:bg-white/10 rounded-full"><span className="material-symbols-outlined text-white">chevron_right</span></button>
            </div>
          </div>
          <div className="grid grid-cols-7 gap-2 text-center mb-2">
            {['S','M','T','W','T','F','S'].map((d,i) => (
              <span key={i} className="text-xs text-gray-500 font-bold">{d}</span>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-2">
            {[...Array(24).keys()].map(i => (
              <div key={i} className={`h-10 flex items-center justify-center rounded-full text-sm text-gray-400 ${i === 23 ? 'bg-primary text-white font-bold shadow-lg shadow-primary/30' : 'hover:bg-white/5'}`}>
                {i + 1}
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-white text-lg font-bold">Available slots for Oct 24</h3>
          <div className="grid grid-cols-2 gap-3">
            {timeSlots.map(slot => (
              <button
                key={slot.id}
                onClick={() => setSelectedSlot(slot.id)}
                className={`h-12 rounded-xl border font-medium transition-all ${
                  selectedSlot === slot.id 
                    ? 'bg-accent border-accent text-background-dark font-bold' 
                    : 'bg-surface-dark border-white/10 text-white hover:border-white/30'
                }`}
              >
                {slot.label}
              </button>
            ))}
          </div>
        </div>
      </main>

      <div className="px-4 py-4 bg-background-dark border-t border-white/5">
        <button 
          onClick={() => navigate(`/confirmation?type=${type}&time=${selectedSlot || '10:00'}`)}
          disabled={!selectedSlot}
          className="w-full bg-primary disabled:opacity-50 hover:bg-primary-light text-white font-bold h-14 rounded-full shadow-lg shadow-primary/30 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          <span>Confirm Schedule</span>
          <span className="material-symbols-outlined">check_circle</span>
        </button>
      </div>
    </div>
  );
};