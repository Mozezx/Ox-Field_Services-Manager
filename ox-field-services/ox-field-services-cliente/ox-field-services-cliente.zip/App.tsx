import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { Login } from './screens/Login';
import { Home } from './screens/Home';
import { RequestService } from './screens/RequestService';
import { Schedule } from './screens/Schedule';
import { Confirmation } from './screens/Confirmation';
import { Tracking } from './screens/Tracking';
import { Rating } from './screens/Rating';
import { Documents } from './screens/Documents';
import { Profile } from './screens/Profile';
import { Support } from './screens/Support';
import { PaymentMethods } from './screens/PaymentMethods';
import { BottomNav } from './components/BottomNav';

const ProtectedRoute = ({ children }: { children?: React.ReactNode }) => {
  const { isAuthenticated } = useApp();
  if (!isAuthenticated) return <Navigate to="/" replace />;
  return <>{children}</>;
};

const Layout = () => {
  const location = useLocation();
  // Hide bottom nav on specific screens
  const hideNavPaths = ['/', '/request', '/schedule', '/confirmation', '/tracking', '/rating', '/support', '/chat', '/payments'];
  const showNav = !hideNavPaths.includes(location.pathname);

  return (
    <>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
        <Route path="/request" element={<ProtectedRoute><RequestService /></ProtectedRoute>} />
        <Route path="/schedule" element={<ProtectedRoute><Schedule /></ProtectedRoute>} />
        <Route path="/confirmation" element={<ProtectedRoute><Confirmation /></ProtectedRoute>} />
        <Route path="/tracking" element={<ProtectedRoute><Tracking /></ProtectedRoute>} />
        <Route path="/rating" element={<ProtectedRoute><Rating /></ProtectedRoute>} />
        <Route path="/documents" element={<ProtectedRoute><Documents /></ProtectedRoute>} />
        <Route path="/appointments" element={<ProtectedRoute><Documents /></ProtectedRoute>} /> {/* Reusing docs for simplicity as per prompt grouping */}
        <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
        <Route path="/support" element={<ProtectedRoute><Support /></ProtectedRoute>} />
        <Route path="/notifications" element={<ProtectedRoute><Support /></ProtectedRoute>} />
        <Route path="/payments" element={<ProtectedRoute><PaymentMethods /></ProtectedRoute>} />
      </Routes>
      {showNav && <BottomNav />}
    </>
  );
};

export default function App() {
  return (
    <AppProvider>
      <Router>
        <Layout />
      </Router>
    </AppProvider>
  );
}