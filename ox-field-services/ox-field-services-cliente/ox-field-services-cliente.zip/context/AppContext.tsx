import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ServiceRequest, User, Notification } from '../types';

interface AppContextType {
  user: User;
  activeService: ServiceRequest | null;
  setActiveService: (service: ServiceRequest | null) => void;
  pastServices: ServiceRequest[];
  notifications: Notification[];
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
  addService: (service: ServiceRequest) => void;
}

const defaultUser: User = {
  name: "Michael",
  email: "michael.ox@example.com",
  avatar: "https://i.pravatar.cc/150?u=michael",
  addresses: [
    { id: '1', label: 'Home', fullAddress: '123 Maple St, Springfield, IL' },
    { id: '2', label: 'Office', fullAddress: 'Ox Field HQ, Suite 400, Chicago, IL' }
  ]
};

const defaultNotifications: Notification[] = [
  { id: '1', title: 'Technician Arriving Soon', message: 'Your technician, Mike, is 10 minutes away.', time: '10:05 AM', type: 'info', read: false },
  { id: '2', title: 'Invoice #1024 Available', message: 'View your invoice for the recent plumbing service.', time: '09:00 AM', type: 'info', read: false },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children?: ReactNode }) => {
  const [user] = useState<User>(defaultUser);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeService, setActiveService] = useState<ServiceRequest | null>(null);
  const [notifications] = useState<Notification[]>(defaultNotifications);
  const [pastServices, setPastServices] = useState<ServiceRequest[]>([
    { id: 'hvac-01', type: 'HVAC', status: 'Completed', date: 'Oct 12, 2023', time: '10:00 AM', address: '123 Maple St', price: 165.00 },
    { id: 'plumb-02', type: 'Plumbing', status: 'Completed', date: 'Sep 28, 2023', time: '2:00 PM', address: '123 Maple St', price: 120.00 }
  ]);

  const login = () => setIsAuthenticated(true);
  const logout = () => setIsAuthenticated(false);
  
  const addService = (service: ServiceRequest) => {
    setActiveService(service);
    // In a real app, this would also add to a pending list
  };

  return (
    <AppContext.Provider value={{ 
      user, 
      activeService, 
      setActiveService, 
      pastServices, 
      notifications, 
      isAuthenticated, 
      login, 
      logout,
      addService
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};