import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

export const BottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { icon: 'home', label: 'Home', path: '/home' },
    { icon: 'calendar_month', label: 'Requests', path: '/appointments' },
    { icon: 'description', label: 'Docs', path: '/documents' },
    { icon: 'person', label: 'Profile', path: '/profile' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-surface-dark border-t border-white/5 pb-safe pt-2 px-2 z-50">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        {navItems.map((item) => (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className="flex flex-col items-center justify-center gap-1 w-16 group transition-all duration-200 active:scale-95"
          >
            <span 
              className={`material-symbols-outlined transition-colors duration-200 ${
                isActive(item.path) 
                  ? 'text-accent filled' 
                  : 'text-gray-500 group-hover:text-gray-300'
              }`}
            >
              {item.icon}
            </span>
            <span 
              className={`text-[10px] font-medium transition-colors duration-200 ${
                isActive(item.path) 
                  ? 'text-accent' 
                  : 'text-gray-500 group-hover:text-gray-300'
              }`}
            >
              {item.label}
            </span>
          </button>
        ))}
      </div>
      <div className="h-safe-bottom w-full bg-surface-dark" />
    </nav>
  );
};